package com.example.pointtopoint;

public class Utils {
    public static final String EMAIL = "pointtopointapp@gmail.com";
    public static final String PASSWORD = "Pointtopoint123";
}
